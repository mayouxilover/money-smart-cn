---
name: tuye-github-qunzhan
description: >
  图爷的一人公司 GitHub Pages 群站建站与部署全流程方法论。用于批量创建、管理、
  部署基于 Markdown + Python 脚本生成静态 HTML 的 GitHub Pages 内容网站，
  含 AdSense 变现、SEO 优化、双仓库部署策略。当用户提到"建站""群站""新站"
  "GitHub Pages""批量生成网站""AdSense 变现"或需要复用钱智汇建站经验时触发。
agent_created: true
---

# 图爷 GitHub 群站建站方法论

基于钱智汇（Money Smart CN）项目实战总结的全流程建站方法论。核心思路：
**Markdown 写作 → Python 脚本生成静态 HTML → GitHub Pages 部署 → AdSense 变现**。

## 适用场景

- 创建新的内容型 GitHub Pages 站点（金融、保险、科技、生活等领域）
- 批量扩展站群中的新站点
- 对现有站点进行 SEO 优化、AdSense 集成、GDPR 合规改造
- 修复站点日期错误、404 问题、部署失败等运维问题

## 全流程 SOP

### 阶段 1: 站点规划

1. 确定利基领域和关键词策略（高 CPM 词优先）
2. 设计内容矩阵：核心文章 + 扩展文章
3. 确定站点名称、域名、变现方式
4. 创建 GitHub 仓库（项目仓库 + 根域名仓库）

### 阶段 2: 内容生成

1. 在 `_posts/` 目录创建 Markdown 文章，命名格式: `YYYY-MM-DD-slug.md`
2. 每篇文章含 frontmatter: `layout`, `title`, `date`, `categories`, `tags`, `description`
3. 文章结构: 摘要 → 3-5 个章节（H2+H3） → FAQ → 免责声明
4. 每篇文章 4-5 个 SEO 标签

**日期规则（关键）**:
- 创建文章前，先用 `date +%Y-%m-%d` 获取当天日期
- 所有文章日期不得超越当天
- 新增文章在已有日期范围最大值和今天之间均匀分布
- 示例: 已有文章到 06-04，今天是 06-06，新增文章用 06-05

### 阶段 3: 站点生成

1. 基于 `assets/convert_md_to_html_template.py` 配置关键变量:
   ```python
   SITE_URL = "https://<username>.github.io"  # 根域名
   POSTS_DIR = "_posts"
   OUTPUT_DIR = "html"
   ```
2. 生成全站: `python convert_md_to_html.py`
3. 确认 `html/` 目录包含所有文件（文章、分类页、标签页、静态页、sitemap.xml）
4. 将 html/ 内容复制到仓库根目录: `cp -r html/* .`

### 阶段 4: SEO 优化

站点生成脚本应包含以下优化项:

| 优化项 | 说明 |
|--------|------|
| JSON-LD 结构化数据 | Article + FAQPage + BreadcrumbList + WebSite + Organization |
| sitemap.xml | 含 lastmod/changefreq/priority |
| 面包屑导航 | 所有内容页顶部显示 |
| 上一篇/下一篇 | 文章页底部 rel="prev/next" 导航 |
| Open Graph + Twitter Card | 社交分享元标签 |
| Canonical URL | 防止重复内容 |
| `.nojekyll` | 禁用 Jekyll，确保 AdSense 脚本不被剥离 |

### 阶段 5: AdSense 集成

1. **验证标签**（双重验证）:
   ```html
   <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXX"></script>
   <meta name="google-adsense-account" content="ca-pub-XXXX">
   ```
2. **Consent Mode v2**（在所有 AdSense 脚本之前）:
   ```javascript
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('consent', 'default', {
     'ad_storage': 'denied',
     'ad_user_data': 'denied',
     'ad_personalization': 'denied',
     'analytics_storage': 'denied',
     'wait_for_update': 500
   });
   ```
3. **合规页面**: 隐私政策、联系我们、服务条款
4. **CMP 消息**: 在 AdSense 控制台创建并发布 GDPR 消息

### 阶段 6: 部署

**双仓库策略**:

| 仓库 | URL | 用途 |
|------|-----|------|
| `<user>.github.io` | `https://<user>.github.io/` | 根域名（AdSense 认可） |
| `<project-name>` | `https://<user>.github.io/<project>/` | 源码仓库（同步备份） |

**推送方法（避免 HTTP 408）**:

```bash
# 使用 gh auth token 认证
TOKEN=$(gh auth token)
git clone --depth 1 "https://gho_push:${TOKEN}@github.com/<user>/<repo>.git" ./repo
cp -r html/* ./repo/
cd ./repo && git add -A && git commit -m "deploy" && git push origin main
```

也可使用 `scripts/deploy.py` 自动化部署:
```bash
python scripts/deploy.py                    # 部署两个仓库
python scripts/deploy.py --root-only        # 仅根域名
python scripts/deploy.py --dir ./dist       # 指定源目录
```

### 阶段 7: 验证

部署后必须验证:
1. 首页: `https://<user>.github.io/` → 200
2. 文章页: 随机抽查 3-5 个 → 200
3. 隐私政策: `/privacy` → 200
4. sitemap: `/sitemap.xml` → 200
5. AdSense 标签: 查看页面源代码确认
6. 日期检查: 无未来日期

## 关键路径引用

- 模板脚本: `assets/convert_md_to_html_template.py`
- 部署脚本: `scripts/deploy.py`
- 常见坑: `references/pitfalls.md`

## 维护规则

1. **内存文件**: 项目重要配置写入 `.workbuddy/memory/MEMORY.md`
2. **日常日志**: 每次操作后追加 `.workbuddy/memory/YYYY-MM-DD.md`
3. **日期纪律**: 每次操作前检查当天日期，文章不设未来日期
4. **推送纪律**: 优先用 `gh auth token` 方式推送，超大仓库用浅克隆
5. **变更日志**: commit message 用中文描述变更内容
