#!/usr/bin/env python3
"""GitHub Pages 群站部署脚本

使用 gh auth token 认证方式推送，避免 HTTP 408 超时。
支持双仓库同步部署（rootrepo + origin）。

用法:
    python deploy.py                        # 从 html/ 部署两个仓库
    python deploy.py --root-only            # 仅部署根域名仓库
    python deploy.py --source-only          # 仅部署源码仓库
    python deploy.py --dir ./dist           # 指定源目录（默认 html/）
"""

import os
import sys
import shutil
import subprocess
import argparse
import tempfile


def get_gh_token():
    """获取 GitHub CLI token"""
    result = subprocess.run(
        ["gh", "auth", "token"],
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        print("[ERROR] gh auth token 获取失败，请先执行 gh auth login")
        sys.exit(1)
    return result.stdout.strip()


def clone_and_push(repo_name, source_dir, gh_token):
    """浅克隆仓库、复制文件、提交推送"""
    repo_url = f"https://gho_push:{gh_token}@github.com/{repo_name}.git"
    temp_dir = tempfile.mkdtemp(prefix="deploy_")

    print(f"[DEPLOY] 部署到 {repo_name}")
    print(f"  1/4 浅克隆...")
    
    result = subprocess.run(
        ["git", "clone", "--depth", "1", repo_url, temp_dir],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print(f"  [ERROR] 克隆失败: {result.stderr}")
        return False

    print(f"  2/4 复制文件...")
    # 删除旧文件（保留 .git）
    for item in os.listdir(temp_dir):
        if item != ".git":
            item_path = os.path.join(temp_dir, item)
            if os.path.isdir(item_path):
                shutil.rmtree(item_path)
            else:
                os.remove(item_path)
    
    # 复制新文件
    for item in os.listdir(source_dir):
        src = os.path.join(source_dir, item)
        dst = os.path.join(temp_dir, item)
        if os.path.isdir(src):
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)

    print(f"  3/4 提交...")
    subprocess.run(
        ["git", "-C", temp_dir, "config", "user.email", "mayouxilover@gmail.com"],
        capture_output=True
    )
    subprocess.run(
        ["git", "-C", temp_dir, "config", "user.name", "mayouxilover"],
        capture_output=True
    )
    subprocess.run(
        ["git", "-C", temp_dir, "add", "-A"],
        capture_output=True
    )
    result = subprocess.run(
        ["git", "-C", temp_dir, "commit", "-m", f"deploy: 全站更新"],
        capture_output=True, text=True
    )

    print(f"  4/4 推送...")
    result = subprocess.run(
        ["git", "-C", temp_dir, "push", "origin", "main"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"  [OK] {repo_name} 推送成功")
    else:
        print(f"  [ERROR] 推送失败: {result.stderr}")

    # 清理临时目录
    shutil.rmtree(temp_dir)
    return result.returncode == 0


def main():
    parser = argparse.ArgumentParser(description="GitHub Pages 群站部署")
    parser.add_argument("--dir", default="html", help="源目录（默认 html/）")
    parser.add_argument("--root-only", action="store_true", help="仅部署根域名仓库")
    parser.add_argument("--source-only", action="store_true", help="仅部署源码仓库")
    parser.add_argument("--github-user", default="mayouxilover", help="GitHub 用户名")
    args = parser.parse_args()

    source_dir = args.dir
    if not os.path.isdir(source_dir):
        print(f"[ERROR] 源目录 '{source_dir}' 不存在")
        sys.exit(1)

    # 确认 .nojekyll 存在
    nojekyll = os.path.join(source_dir, ".nojekyll")
    if not os.path.exists(nojekyll):
        print("[WARN] .nojekyll 不存在，自动创建")
        with open(nojekyll, "w") as f:
            f.write("")

    gh_token = get_gh_token()
    user = args.github_user
    success = True

    if not args.source_only:
        # 根域名仓库：username.github.io
        root_repo = f"{user}/{user}.github.io"
        if not clone_and_push(root_repo, source_dir, gh_token):
            success = False

    if not args.root_only:
        # 源码仓库：从 git remote 获取
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            remote_url = result.stdout.strip()
            # 提取 user/repo
            if "github.com" in remote_url:
                parts = remote_url.split("github.com/")[-1].replace(".git", "")
                if not clone_and_push(parts, source_dir, gh_token):
                    success = False
            else:
                print("[WARN] 无法解析 origin 远程URL，跳过源码仓库")
        else:
            print("[WARN] 无 origin 远程，仅部署根域名仓库")

    if success:
        print("\n[ALL DONE] 部署完成！GitHub Pages 通常需要30-60秒生效。")
    else:
        print("\n[WARN] 部分部署失败，请检查上方错误信息。")
        sys.exit(1)


if __name__ == "__main__":
    main()
