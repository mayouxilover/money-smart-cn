# 常见坑与解决方案

## 推送失败

### HTTP 408 超时
**现象**: `git push` 返回 HTTP 408 或一直挂起
**原因**: Git HTTPS 协议在推送大仓库时超时
**解决方案**:
1. 使用 `gh auth token` 认证替代默认 HTTPS:
   ```bash
   TOKEN=$(gh auth token)
   git remote set-url origin "https://gho_push:${TOKEN}@github.com/user/repo.git"
   git push origin main
   ```
2. 使用浅克隆减少传输量: `git clone --depth 1`
3. 大变更分步推送（markdown → HTML）

### push 后 GitHub Pages 仍返回旧内容
**原因**: GitHub Pages 部署需要 30-120 秒
**解决**: 等待 1-2 分钟后刷新，或查看仓库 Actions 标签确认构建状态

---

## 页面 404

### 根域名 404
**原因**: `<username>.github.io` 仓库不存在或为空
**解决**: 创建同名仓库，推入静态文件

### 子路径 404（/project-name/xxx/）
**原因**: 源码仓库未推送 HTML，或推送失败
**解决**: 
1. 确认 HTML 文件在仓库根目录（不是子目录）
2. 确认 `.nojekyll` 文件存在
3. 检查 GitHub Pages 设置是否启用

### 特定页面 404
**原因**: SITE_URL 配置错误，链接指向错误路径
**解决**: 
1. 检查 `convert_md_to_html.py` 中 `SITE_URL` 变量
2. 根域名部署: `SITE_URL = "https://<username>.github.io"`
3. 子路径部署: `SITE_URL = "https://<username>.github.io/<project>"`

---

## Python 生成脚本问题

### f-string 中 JavaScript 代码报错
**现象**: `SyntaxError: f-string: single '}' is not allowed`
**原因**: JavaScript 代码块中包含 `{}`
**解决**: 将所有 `{` 替换为 `{{`，`}` 替换为 `}}`

### Windows 编码乱码
**现象**: print 输出中文显示为乱码
**原因**: Windows 终端默认编码问题
**解决**: 
1. 脚本不影响实际生成的文件编码（文件用 UTF-8）
2. 可在脚本开头添加: `sys.stdout.reconfigure(encoding='utf-8')`

---

## 日期管理

### 文章日期在未来
**原因**: 未检查当前日期，批量创建时分配了未来日期
**预防**: 
1. 创建文章前先执行 `date +%Y-%m-%d` 获取当天日期
2. 所有文章日期 ≤ 当天日期
3. 新增文章日期在已有范围最大值和今天之间均匀分布

### 年份错误（如 2025 而非 2026）
**原因**: 创建文章时使用了旧年份
**解决**: 编写脚本批量修复文件名和 YAML frontmatter 中的 date 字段

---

## AdSense 审核

### 无法验证网站
**原因**: 
1. 子路径 URL 不被接受（如 `github.io/project/`）
2. 验证标签不在首页
3. Jekyll 剥离了 script 标签
**解决**:
1. 使用根域名 `<username>.github.io` 申请
2. 双重验证: `<script adsbygoogle>` + `<meta google-adsense-account>`
3. 添加 `.nojekyll` 禁用 Jekyll 处理

### CMP / GDPR 合规
**必须包含**:
1. Consent Mode v2 代码（在所有 `<head>` 中，AdSense 脚本之前）
2. 隐私政策页面（含 Cookie 说明和广告说明）
3. Google CMP 消息发布

---

## 双仓库同步

### SITE_URL 不统一
**问题**: rootrepo 用根域名，origin 用子路径，链接不一致
**当前方案**: SITE_URL 统一指向根域名，origin 作为源码备份
**注意**: origin 仓库页面中的链接会跳转到根域名
